# Roadmap Revised Pre-Pilot

## 1. Purpose

This revised phased roadmap reflects the new priority order before Lighting Pilot validation and before any Checklist V1 work.

The project should remain a lightweight church spiritual life and ministry workflow system, not a full church ERP.

## Phase 0 - Source Hygiene / Baseline

- Avoid treating local artifacts as product state.
- Keep repo/zip clean from `.venv`, `env`, `__pycache__`, `.vs`, and local-only artifacts where possible.
- Use current repo state as source of truth.

## Phase 1 - IA / Navigation Reset

- Define top-level navigation.
- Separate Today, Reading, Bible Study, Prayer, My Serving, Profile.
- Group staff management.
- Clarify page responsibilities.
- Fix bilingual nav labels.

## Phase 2 - Completed V1 QA / Stabilization

Items likely completed but needing QA:
- Daily Reading V1
- Prayer V1
- Reflection/reporting
- ServiceEvent Foundation
- MinistryTeam + TeamMembership
- TeamAssignment V1
- My Serving V1
- Lighting import basic flow

Work:
- Fix copy.
- Fix bilingual display.
- Fix stale docs.
- Do not add major features.

## Phase 3 - Bible Study V2 Planning

- Document church structure domain boundaries.
- Clarify fellowship small groups vs MinistryTeam.
- Clarify small-group coworker roles vs TeamAssignment.
- Clarify CM/EM ministry contexts.
- Document two-layer Bible Study model.
- Define BibleStudyLesson and BibleStudyMeeting.
- Define group-level guide/questions.
- Define simple meeting roles.
- Define group-level worship set.
- Define ServiceEvent relationship.
- Define non-goals.

## Phase 4 - Bible Study V2 Implementation

Functional pieces now exist through BS-V2.6.6, including schedule/scope fields, staff IA cleanup, meeting generation, and normal `/studies/` V2 landing integration.

Completed BS-V2.6 sequence:
- BS-V2.6.0 - Schedule/scope replan documentation.
- BS-V2.6.1 - Staff IA cleanup.
- BS-V2.6.2 - Treat BibleStudySeries as Bible Study Schedule / 查经安排.
- BS-V2.6.3 - Add schedule lifecycle fields.
- BS-V2.6.4 - Add schedule scope fields.
- BS-V2.6.5 - Generate group meetings from guide/scope with a manual, idempotent staff action.
- BS-V2.6.6 - Normal user V2 landing integration.

Completed QA:
- BS-V2.6.7 - Bible Study V2 Flow QA passed.

Completed foundation steps:
- CS-F.1 - MinistryContext bridge foundation.
- CS-F.2 - MinistryContext Bible Study Schedule scope.
- CS-F.3 - ServiceEvent MinistryContext label foundation.

Future:
- Future foundation - flexible Church Structure Foundation only after the short-term bridge proves insufficient, before advanced mixed audience segments.
- BS-V2.7 - Role-aware editing permissions later only if needed.

Do not proceed directly to role-aware permissions or new modules after the V2 flow QA pass.
Generated small-group meetings should reference the weekly guide and derive schedule through the guide's series/schedule. Do not copy church-wide guide content into each meeting.

## Phase 5 - Lighting Pilot Preflight Cleanup

- Fix stale Lighting QA docs.
- Validate CSV template/download flow.
- Validate bilingual data.
- Write My Serving member guide.
- Write ministry coordinator guide.
- Confirm dry-run/re-run behavior.
- Confirm no sensitive data import.

## Phase 6 - Lighting Pilot Validation

- Validate real pilot data.
- Validate user visibility.
- Validate coordinator workflow.
- Validate bilingual display.
- Validate no checklist is needed for pilot.

## Phase 7 - Checklist V1

Deferred.

Only reconsider after Lighting Pilot validation.

Keep it minimal when eventually implemented:
- generic checklist template
- assignment-level checklist items
- manual check/uncheck
- no reminders
- no enforcement engine
- no scheduling system

## Future Deferred Module - Community Activities V1

Plan as a separate future module after Bible Study V2 direction is resolved and after Lighting Pilot preflight validation.

Community Activities is for signup-oriented member/community/fellowship activities, such as small group meals, hiking activities, district fellowship, whole-church picnics, or special community gatherings.

Keep it separate from:
- Daily Reading
- Bible Study content
- Prayer
- Ministry Team Operations
- TeamAssignment
- ServiceEvent scheduling
- Checklist V1

ServiceEvent remains the official church gathering, operations, and ministry assignment anchor. CommunityActivity should handle the question "who wants to attend/signup?" while ServiceEvent + TeamAssignment should handle "which ministry team is serving?"

Future Community Activities planning should use audience segments rather than a single simple scope value. Audience segments may target the whole church, a ministry context such as CM/EM, selected districts, or selected small groups. Do not create a separate SpecialEvent model, and do not force CommunityActivity into ServiceEvent.

Advanced mixed audience segments should align with the future Church Structure Foundation plan. See `docs/CHURCH_STRUCTURE_FOUNDATION_PLAN.md`.

Do not add Activities to top navigation yet. A future navigation option may be:
- English: Today, Reading, Bible Study, Prayer, Activities, My Serving, Profile
- Chinese: 今日, 读经, 查经, 代祷, 活动, 我的服事, 个人资料

Checklist V1 remains deferred and should not be revived because of this module.

See `docs/COMMUNITY_ACTIVITIES_V1_PLAN.md`.

## Future CMS Product Scope

These items are future CMS product directions, not authorization to implement them from this roadmap. "Not V1" or "not now" means deferred until separately planned and approved, not outside the final product.

Future CMS scope may include:
- Prayer Wall refinement.
- Bible Study / small group attendance.
- Notifications through email, SMS, WeChat, and app notifications.
- Pastor/staff announcements.
- Group leader dashboard.
- Children/family/couples/newcomer care workflows.
- Activities signup, check-in, and capacity management.
- Resources/materials/file center.
- Finer permission matrix for ministry role, small group leader, district leader, and staff capabilities.

The ERP boundary remains: no finance, payroll, HR/personnel system, full CRM, legal/compliance system, or broad sensitive contact import. Children/family care workflow is future CMS scope; child security check-in is not automatically authorized.

## Current Recommended Next Sequence

- Bible Study V2 Flow QA passed.
- CS-F.1 MinistryContext bridge foundation completed.
- CS-F.2 MinistryContext Bible Study Schedule scope completed.
- CS-F.3 ServiceEvent MinistryContext label foundation completed.
- RC-P.2 Pilot Release Candidate Readiness Pass completed.
- RC-P.3 Pilot release candidate tag `v0.9-pilot-rc1` created and pushed.
- RC-P.4 Pilot Validation Runbook prepared for pilot validation.
- `v0.9-pilot-rc1` deployed and pilot validation passed.
- Current next phase: Post-Pilot Backlog Triage. CS-H.1 Flexible Church Structure and Audience Scope Design Doc is complete, CS-H.2 model-only `ChurchStructureUnit` foundation is complete, CS-H.2A model hardening is complete, CS-H.3 mapping/membership strategy is complete, CS-H.3B nullable legacy mapping fields are complete, CS-H.3C idempotent seeding/mapping command is complete, CS-H.3D production/staging seeding verification passed, CS-H.3E seeded structure data QA closure is complete, CS-H.4 ChurchStructureMembership Design Doc is complete, CS-H.5A ChurchStructureMembership model-only foundation is complete, CS-H.5B membership helper/validation hardening is complete, CS-H.5C membership backfill command is complete, CS-H.5D production/staging backfill verification is complete by user-attested GoDaddy run, CS-H.5E Admin clarity for legacy structure vs future foundation models is complete, CS-H.6 through CS-H.7E complete requested-unit capture and staff approval/sync slices, CS-H.8 integration checkpoint is complete, CS-H.9 membership request UX hardening is complete, CS-H.10 CMS hardening checkpoint is complete, mobile nav polish is deferred/accepted for now, and root `AGENTS.md` verification policy has been added. See `docs/POST_PILOT_BACKLOG_TRIAGE.md`, `docs/FLEXIBLE_CHURCH_STRUCTURE_AND_AUDIENCE_SCOPE_DESIGN.md`, `docs/CHURCH_STRUCTURE_MAPPING_AND_MEMBERSHIP_STRATEGY.md`, `docs/CHURCH_STRUCTURE_SEEDING_VERIFICATION.md`, `docs/CHURCH_STRUCTURE_MEMBERSHIP_BACKFILL_VERIFICATION.md`, and `docs/CHURCH_STRUCTURE_MEMBERSHIP_DESIGN.md`.
- Large deferred items remain deferred pending feedback.
- Flexible Church Structure seeding/mapping now exists only as an explicit dry-run/apply command, passed GoDaddy production/staging verification, and completed seeded data QA closure. CS-H.4 ChurchStructureMembership Design Doc is complete, CS-H.5A adds the model-only membership foundation, CS-H.5B hardens membership helpers/validation, CS-H.5C adds explicit dry-run/apply membership backfill from mapped `Profile.small_group` values, CS-H.5D records user-attested production/staging backfill verification, CS-H.5E improves Django Admin clarity, CS-H.6/CS-H.6B/CS-H.6D add signup and Profile requested-unit capture, and CS-H.7B/C/D/E add staff request review, approve/reject actions, and narrow `Profile.small_group` approval sync. Runtime consumers still primarily use `MinistryContext`, `District`, `SmallGroup`, and `Profile.small_group`; `/studies/`, reading progress, `ServiceEvent`, My Serving, and other consumers are not yet driven by `ChurchStructureMembership`. Audience selection, filtering, broad custom staff admin expansion, and consumer migration remain future and phased.
- Lighting Pilot operational follow-up and Community Activities planning should be classified through post-pilot backlog planning before implementation.
- Later role-aware editing permissions.
- Later ServiceEvent participating_ministries / MinistryContext audience planning.
- Later Community Activities V1 with audience segments.
- Checklist V1 remains deferred unless pilot feedback proves need.
